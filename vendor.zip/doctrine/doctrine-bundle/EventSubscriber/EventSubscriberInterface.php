<?php

namespace Doctrine\Bundle\DoctrineBundle\EventSubscriber;

use Doctrine\Common\EventSubscriber;

interface EventSubscriberInterface extends EventSubscriber
{
}
