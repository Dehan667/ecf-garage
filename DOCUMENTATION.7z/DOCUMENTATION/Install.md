# Installation Environnement Symfony
## Etape 1 : Installation de Docker

[![N|Solid](https://www.1min30.com/wp-content/uploads/2018/04/Logo-Docker-500x281.jpg)](https://nodesource.com/products/nsolid)

### Docker Desktop

Téléchargez la version de [Docker Desktop](https://www.docker.com/get-started/) correspondant à votre OS.
Exécutez l'installation et redémarrer la machine si demandé.

> Note: Pour les utilisateurs Windows, veillez à bien installer la version `WSL2`.
> Au redémarrage, l'installateur demandera à installer WSL2 sur la machine, pour cela, suivre les instructions de la boite de commande (et bien redémarrer une seconde fois)
>
>  <img src="https://zupimages.net/up/22/20/9zhg.png" alt="wsl2" style="zoom:80%;" />



### Récupération du projet

![cmder](https://c.clc2l.com/c/thumbnail75webp/t/-/5/-5VRgnA.jpg)

Récupérez cmder avec le package comprenant git for Windows.

Rendez vous dans le répertoire de destination du projet et lancez la récupération du repository 

```
git clone https://github.com/Dehan667/ecf-garage
```



### Docker Compose

Maintenant que Docker est installé, le projet récupéré, il faut monter les containers. Le Dockerfile est déjà présent dans le projet, il ne reste qu'à lancer le build

```
docker-compose build
```

L'image va être construite, un certain temps est nécessaire pour télécharger les dépendances. Une fois terminé, démarrez l'environnement du projet

```
docker-compose up -d
docker-compose ps
```

> la seconde ligne permet de vérifier l'état des différents container de l'image Docker



## Etape 2 : Symfony

### Installation Symfony-cli

#### Utilisateurs Windows : Installer Scoop

Lancer une session Windows Powershell

```
> Set-ExecutionPolicy RemoteSigned -Scope CurrentUser 
> irm get.scoop.sh | iex
```

Puis retournez dans cmder, dans le répertoire du projet :

`Scoop install symfony-cli`


### Installation Yarn

```
scoop install nodejs
scoop install yarn
```

et compilez les fichiers yarn 

```
yarn install
yarn run encore dev
```



## Etape 3 : Fonctionnalités projet

Pour récupérer le schéma de données nécessaire, jouez les migrations présentes sur le projet.

```
symfony console d:m:migrate
```

Lors de la première connexion, un compte admin est déjà créé.

Les identifiants sont les suivants : 

```
login : v.parrot@garage.fr
pwd : vpgarage1+
```
login emplyé : employé2@mail.com
pwd : mecanique2

Une fois connecté, il est vivement recommandé de créer un nouveau compte admin depuis le BackOffice et de supprimer le compte par défaut par mesure de sécurité.

Pour envoyer le mail de confirmation (créé lors de l'ajout du compte), jouez la commande suivante :

```
symfony console messenger:consume
```

et suivez la marche à suivre.